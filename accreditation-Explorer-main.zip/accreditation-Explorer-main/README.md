# accreditation-Explorer

## About

Graph database for representing an academic program such as the Masters of Information Technology and its associated material for accreditation.

## Features
- A database for representing an academic program such as the Masters of Information Technology and its associated material for accreditation.

- Interactive visualisation of an academic program and its accreditation material, enabling the user to zoom in and out and to call up specific details such as outcomes mappings.

## Software Requirements
Neo4J version: 4.3.2 or above

OS: Windows 10, MacOS Mojave or later 

## Setup
1. Download and install Neo4j Desktop from https://neo4j.com/download/
2. Create a new project, rename accordingly, and create a new database
3. Copy the CSV files in data folder to the newly created database import directory
4. Run the database and select the option “open in Neo4j browser”
5. Copy first block of code and paste into query interface
6. Click run button and wait until the query finished
7. Copy next block of code, repeat step 5 & 6 until the end of main file

## Data

|File Name|Content|Structure|
|:--|:--|:--|
|activity.csv|Unit Activities|<ul><li>unitCode: string, to uniquely identify a unit</li><li>unit: string, name of unit</li><li>activity: string, to match different activity according to unit</li></ul>|
|advisable\_prior_study.csv|Unit Prior Studies Prerequisites|<ul><li>unitCode: string, uniquely identify a unit that one wants to study</li><li>apUnitCode: string, uniquely identify a unit advised to have studied before</li></ul>|
|AQF.csv|Unit Outcomes and AQF ID|<ul><li>unitCode: string, uniquely identify a unit</li><li>aqfId: string, identify corresponding AQF Id </li><li>outcomeId: integer, corresponding to unit outcome Id</li></li></li></ul>|
|cbok_end.csv|End Level CBoK (E.g: abstraction)|<ul><li>End: End levels CBoK</li><li>Sub: Sub levels CBoK, map to End levels</li></ul>|
|cbok_sub.csv|Sub Level CBoK (E.g: problem solving)|<ul><li>Sub: Sub levels CBoK</li><li>Top: Top levels CBoK, map to Sub levels</li></ul>|
|cbok_top.csv|Top Level CBoK (E.g: General, Essential)|Two lines string containing CBoK top level knowledge areas|
|course.csv|Program Course Information|<ul><li>courseCode: string, uniquely identify course</li><li>title: string</li><li>abbreviation: string, abbreviation of the course title</li><li>CRICOSCode: string</li><li>degree: string, it is either PG or UG</li></ul>|
|MIT_AQF_Outcome_cat.csv|AQF categories for MIT|<ul><li>Program: string, abbreviated program name (MIT)</li><li>ID: integer, used to identify AQF category</li><li>Category: string, AQF category name </li><li>Description: string, full description </li></ul>|
|MIT_AQF_Outcomes .csv|AQF outcomes for MIT|<ul><li>aqfId: string, used to identify aqf outcome </li><li>Description: string, full outcome description</li><li>Area_ key : integer, used to link to aqf category </li></ul>|
|incompatibilities.csv|Units Incompatibilites|<ul><li>unitCode: string, uniquely identify a unit</li><li>iUnitCode: string, uniquely identify a unit that is incompatible with unitCode.</li></ul>|
|outcome.csv|Unit Outcomes|<ul><li>unitCode: string, uniquely identify a unit</li><li>outcome: string, to match different outcome according to unit</li><li>outcomeId: integer, label the outcome in the unit with a serial number</li><li>level: string</li><li>describe: string, to explain the level means</li></ul>|
|prer_course.csv|Course Prerequisites for Units|<ul><li>unitCode: string, uniquely identify a unit</li><li>courseCode: string, uniquely identify a course</li></ul>|
|prer_program.csv|Programming Units Prerequisites|<ul><li>unitCode: string, uniquely identify a unit</li><li>programmingPoint: integer, points of programming-based units required by specific unit</li></ul>|
|prer_unit.csv|Unit to Unit Prerequisites|<ul><li>unitCode: string, uniquely identify a unit</li><li>preUnitCode: string, uniquely identify a unit studied</li></ul>|
|role.csv|Units Role in Program Course|<ul><li>unitCode: string, uniquely identify a unit</li><li>courseCode: string, uniquely identify a course</li><li>role: string, Conversion, Option or Conversion</li></ul>|
|unit.csv|Units Information|<ul><li>unitCode: string, unit code</li><li>title: string</li><li>credit: integer, each unit has 6 points</li><li>programmingBased: integer, 0 or 1, 0 for non-programming-based, 1 for programming-based</li><li>availabilities: string</li></ul>
|unit\_activity_cbok.csv|Unit-Activities-CBoK Mappings|<ul><li>unitCode: uniquely identify a unit</li><li>unit: string, name of unit</li><li>activity: string,  activity title of a unit</li><li>knowledge: string, CBoK knowledge area</li><li>taxonomy: string, Bloom’s taxonomy </li></ul>|


## Example
![CITS1001 Example](./image/CITS1001_example.png)

## Contributors

|Name|Student Number|
|:--|:--|
|Akmal Fadlurohman|23020648|
|Jack Challis|22177023|
|Jinshuai Fu|22960988|
|Xingsheng Liang|22927631|
|Yao Jing|22463676|
